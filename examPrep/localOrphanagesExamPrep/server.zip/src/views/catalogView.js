import { html } from "../../node_modules/lit-html/lit-html.js"
import { getAllItems } from '../api/data.js';
let page = null;

export async function catalogView(ctx) {
    debugger
    page = ctx.page
    console.log('haha')
    let data = await getAllItems();
    ctx.render(template(data))
}


function template(data) {

    return html`
<section id="dashboard-page">
    <h1 class="title">All Posts</h1>

    <!-- Display a div with information about every post (if any)-->

    <div class="all-posts">
        ${data.length > 0 ? html`${data.map(templatePost)}`
       : html`<h1 class="title no-posts-title">No posts yet!</h1>`}
    </div>

    <!-- Display an h1 if there are no posts -->

</section>
    `
}

function templatePost(item) {
    let itemImg = item.imageUrl.split('/').pop()
    return html`
    <div class="post">
        <h2 class="post-title">${item.title}</h2>
        <img class="post-image" src="${"/images/" + itemImg}" alt="Material Image">
        <div class="btn-wrapper">
            <a href="/details/${item._id}" class="details-btn btn">Details</a>
        </div>
    </div>
    `
}