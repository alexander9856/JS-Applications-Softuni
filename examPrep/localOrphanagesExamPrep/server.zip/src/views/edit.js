import { html } from "../../node_modules/lit-html/lit-html.js"
import { getElementById } from '../api/data.js';
import { updateAd } from '../api/data.js'

let context = null;

export async function editView(ctx) {
    context = ctx
    let id = ctx.params.id
    let item = await getElementById(id)
    ctx.render(catalogTemp(item))
}


function catalogTemp(post) {
    return html`
    <section id="edit-page" class="auth">
        <form @submit=${onEdit} id="edit">
            <h1 class="title">Edit Post</h1>
    
            <article class="input-group">
                <label for="title">Post Title</label>
                <input type="title" name="title" id="title" value="${post.title}">
            </article>
    
            <article class="input-group">
                <label for="description">Description of the needs </label>
                <input type="text" name="description" id="description" value="${post.description}">
            </article>
    
            <article class="input-group">
                <label for="imageUrl"> Needed materials image </label>
                <input type="text" name="imageUrl" id="imageUrl" value="${post.imageUrl}">
            </article>
    
            <article class="input-group">
                <label for="address">Address of the orphanage</label>
                <input type="text" name="address" id="address" value="${post.address}">
            </article>
    
            <article class="input-group">
                <label for="phone">Phone number of orphanage employee</label>
                <input type="text" name="phone" id="phone" value="${post.phone}">
            </article>
    
            <input type="submit" class="btn submit" value="Edit Post">
        </form>
    </section>
    `

    async function onEdit(ev) {

        ev.preventDefault()
        let formData = new FormData(ev.target);
        let title = formData.get('title');
        let description = formData.get('description')
        let imageUrl = formData.get('imageUrl')
        let address = formData.get('address')
        let phone = formData.get('phone')
        let id = context.params.id
        if (title, description,imageUrl, address, phone) {
            await updateAd(id, { title, description,imageUrl, address, phone })
            context.page.redirect(`/details/${id}`)
        }
        else {
            alert('All fields are required!')
        }
    }

}

