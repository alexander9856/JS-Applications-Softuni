import { html } from "../../node_modules/lit-html/lit-html.js"
import { getAllItems } from '../api/data.js';
import { getElementById } from '../api/data.js'
let page = null;

export async function catalogView(ctx) {
    page = ctx.page
    let data = [];
    ctx.render(template(data))
}


function template(data) {

    return html`
    <section id="dashboard">
        <h2>Job Offers</h2>
        <!-- Display a div with information about every post (if any)-->
        ${data.length > 0 ? html`${data.map(templateJob)}` 
        : html`<h2>No offers yet.</h2>`}
        <!-- Display an h2 if there are no posts -->
    </section>
    `
}

function templateJob(item){
    return html `
    <div class="offer">
            <img src="./images/example1.png" alt="example1" />
            <p>
                <strong>Title: </strong><span class="title">Sales Manager</span>
            </p>
            <p><strong>Salary:</strong><span class="salary">1900</span></p>
            <a class="details-btn" href="">Details</a>
        </div>
    `
}