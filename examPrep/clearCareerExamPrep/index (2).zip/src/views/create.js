import { html } from "../../node_modules/lit-html/lit-html.js"
import { createAd } from '../api/data.js'
let context = null;

export function createView(ctx) {
    context = ctx
    ctx.render(catalogTemp())
}

function catalogTemp() {
    return html`
    <section id="create">
          <div class="form">
            <h2>Create Offer</h2>
            <form @submit=${onCreate} class="create-form">
              <input
                type="text"
                name="title"
                id="job-title"
                placeholder="Title"
              />
              <input
                type="text"
                name="imageUrl"
                id="job-logo"
                placeholder="Company logo url"
              />
              <input
                type="text"
                name="category"
                id="job-category"
                placeholder="Category"
              />
              <textarea
                id="job-description"
                name="description"
                placeholder="Description"
                rows="4"
                cols="50"
              ></textarea>
              <textarea
                id="job-requirements"
                name="requirements"
                placeholder="Requirements"
                rows="4"
                cols="50"
              ></textarea>
              <input
                type="text"
                name="salary"
                id="job-salary"
                placeholder="Salary"
              />

              <button type="submit">post</button>
            </form>
          </div>
        </section>
    `
}

async function onCreate(ev) {
  
    ev.preventDefault();
    debugger
    let formData = new FormData(ev.target);
    let title = formData.get('title');
    let imageUrl = formData.get('imageUrl')
    let category = formData.get('category')
    let description = formData.get('description')
    let requirements = formData.get('requirements')
    let salary = formData.get('salary')
    if (title, imageUrl,category, description, requirements, salary) {
        await createAd({title, imageUrl,category, description, requirements, salary})
        context.page.redirect('/catalog')
        ev.target.reset()
    }
    else{
        alert('All fields are required!')
    }
}
