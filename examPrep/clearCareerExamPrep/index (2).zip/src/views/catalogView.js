import { html } from "../../node_modules/lit-html/lit-html.js"
import { getAllItems } from '../api/data.js';
let page = null;

export async function catalogView(ctx) {
    debugger
    page = ctx.page
    console.log('haha')
    let data = await getAllItems();
    ctx.render(template(data))
}


function template(data) {

    return html`
    <section id="dashboard">
        <h2>Job Offers</h2>
        <!-- Display a div with information about every post (if any)-->
        ${data.length > 0 ? html`${data.map(x => templateJob(x))}` 
        : html`<h2>No offers yet.</h2>`}
        <!-- Display an h2 if there are no posts -->
    </section>
    `
}

function templateJob(item){
    let itemImg = item.imageUrl.split('/').pop()

    return html `
    <div class="offer">
            <img src="${"/images/" + itemImg}" alt="example1" />
            <p>
                <strong>Title: </strong><span class="title">${item.title}</span>
            </p>
            <p><strong>Salary:</strong><span class="salary">${item.salary}</span></p>
            <a class="details-btn" href="/details/${item._id}">Details</a>
        </div>
    `
}