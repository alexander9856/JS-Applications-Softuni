import { html } from "../../node_modules/lit-html/lit-html.js"
import { getElementById } from '../api/data.js';
import { updateAd } from '../api/data.js'

let context = null;

export async function editView(ctx) {
    context = ctx
    let id = ctx.params.id
    let item = await getElementById(id)
    ctx.render(catalogTemp(item))
}


function catalogTemp(ad) {
    return html`
    <section id="edit">
        <div class="form">
            <h2>Edit Offer</h2>
            <form @submit=${onEdit} class="edit-form">
                <input type="text" name="title" id="job-title" placeholder="Title" .value=${ad.title} />
                <input type="text" name="imageUrl" id="job-logo" placeholder="Company logo url" .value=${ad.imageUrl} />
                <input type="text" name="category" id="job-category" placeholder="Category" .value=${ad.category} />
                <textarea id="job-description" name="description" placeholder="Description" rows="4" cols="50">${ad.description}</textarea>
                <textarea id="job-requirements" name="requirements" placeholder="Requirements" rows="4"
                    cols="50">${ad.requirements}</textarea>
                <input type="text" name="salary" id="job-salary" placeholder="Salary" .value=${ad.salary} />
    
                <button type="submit">post</button>
            </form>
        </div>
    </section>
    `

    async function onEdit(ev) {

        ev.preventDefault()
        debugger
        let formData = new FormData(ev.target);
        let title = formData.get('title');
        let imageUrl = formData.get('imageUrl')
        let category = formData.get('category')
        let description = formData.get('description')
        let requirements = formData.get('requirements')
        let salary = formData.get('salary')
        let id = context.params.id
        if (title, imageUrl,category, description, requirements, salary) {
            await updateAd(id, { title, imageUrl,category, description, requirements, salary })
            context.page.redirect('/catalog')
        }
        else {
            alert('All fields are required!')
        }
    }

}

