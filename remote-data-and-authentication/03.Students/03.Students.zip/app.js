function students() {
    let tbodyRes = document.querySelector('#results tbody')
    async function reload(){
        try {
            let res2 = await fetch(`http://localhost:3030/jsonstore/collections/students`)
            if (res2.ok == false) {
                throw new Error('Error')
            }
            let data = await res2.json()
            tbodyRes.innerHTML = ''
            for (let i in data) {                    
                tbodyRes.innerHTML += `
                    <tr>
                        <td>${data[i].firstName}</td>
                        <td>${data[i].lastName}</td>
                        <td>${data[i].facultyNumber}</td>
                        <td>${Number(data[i].grade).toFixed(2)}</td>
                    </tr>`
            }
        }
        catch (err) {
            alert(err.message)
        }
        }
        reload()
    document.getElementById('submit').addEventListener('click', submit)

    async function submit(ev) {
        ev.preventDefault()
        let firstName = document.getElementsByClassName('inputs')[0].children[0].value
        let lastName = document.getElementsByClassName('inputs')[0].children[1].value
        let facultyNumber = document.getElementsByClassName('inputs')[0].children[2].value
        let grade = document.getElementsByClassName('inputs')[0].children[3].value
        if (firstName && lastName && facultyNumber && !isNaN(grade) && grade) {
            try {
                let res = await fetch(`http://localhost:3030/jsonstore/collections/students`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        firstName,
                        lastName,
                        facultyNumber,
                        grade
                    })
                })
                if (res.ok == false) {
                    throw new Error('Error')
                }
            }
            catch (err) {
                alert(err.message)
            }
            await reload()
            document.getElementsByClassName('inputs')[0].children[0].value = ''
            document.getElementsByClassName('inputs')[0].children[1].value = ''
            document.getElementsByClassName('inputs')[0].children[2].value = ''
            document.getElementsByClassName('inputs')[0].children[3].value = ''

        }
    }

}
students()

// let url = 'http://localhost:3030/jsonstore/collections/students'
// async function reload(){
 
// fetch(url, {
//     method: 'GET'
// })
// .then(res => res.json())
// .then(data => Object.values(data).forEach(element => {
//     let toappend = document.querySelector('tbody')
//     let thead = document.createElement('tr')
//     thead.innerHTML =`
//                       <td>${element.firstName}</td>
//                       <td>${element.lastName}</td>
//                       <td>${element.facultyNumber}</td>
//                       <td>${element.grade}</td>
 
//                       `
//                       toappend.appendChild(thead)
// }))
// }reload()
// let form = document.querySelectorAll('input')
// let submit = document.getElementById('submit')
// submit.addEventListener('click', OnClick)
// function OnClick(e){
// e.preventDefault()
 
// let firstname = form[0].value
// let secondname = form[1].value
// let facultynumber = form[2].value
// let grade = form[3].value
 
// fetch(url, {
// method: 'POST',
// body: JSON.stringify({
//     firstName: firstname.trim(),
//     lastName: secondname,
//     facultyNumber: facultynumber,
//     grade: grade
// })
// }).then(resp => {
//     if (resp.ok == false) {
//         throw new Error('Error')
//     }
//     document.querySelectorAll('input')[0].value = ''
//     document.querySelectorAll('input')[1].value = ''
//     document.querySelectorAll('input')[2].value = ''
//     document.querySelectorAll('input')[3].value = ''
 
//     return resp.json()
// })
 
// .catch(err => alert(err))
 
 
// }